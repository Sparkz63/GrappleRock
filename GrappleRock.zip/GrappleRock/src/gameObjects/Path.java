package gameObjects;

public class Path {

}
