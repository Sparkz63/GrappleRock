package gameObjects;

public enum Shape {
	SQUARE, TRIANGLE, CIRCLE
};
