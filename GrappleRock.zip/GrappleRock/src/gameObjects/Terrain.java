package gameObjects;

public class Terrain {
	// Contains Obstacles and shit
}
