package util;

public class Location {
	public int x, y;
}
