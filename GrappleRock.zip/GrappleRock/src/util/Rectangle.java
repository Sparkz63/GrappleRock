package util;

public class Rectangle {
	public Location position = new Location();
	public int width, height;
}
